package app.vehicleguard

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

class MainActivity : ComponentActivity() {
    private lateinit var p: SharedPreferences
    private var armed by mutableStateOf(false)
    private var run by mutableStateOf(false)
    private var homeOn by mutableStateOf(false)
    private var homeTxt by mutableStateOf("")
    private var mode = 0
    private var dist by mutableStateOf(0f)
    private val ls = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> load() }
    private val perm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            if (mode != 2 && Build.VERSION.SDK_INT >= 29 && checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED)
                bgPerm.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            else proceed()
        }
    }
    private val bgPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { proceed() }
    private fun proceed() { when (mode) { 0 -> arm(); 1 -> goHome(); else -> pickHome() } }

    private fun load() { armed = p.getBoolean("armed", false); run = p.getBoolean("run", false); homeOn = p.getBoolean("homeSched", true); dist = p.getFloat("dist", 0f) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("g", 0); load()
        p.getString("hlat", null)?.let { homeTxt = "$it, ${p.getString("hlon", "")}" }
        p.registerOnSharedPreferenceChangeListener(ls)
        setContent { MaterialTheme { UI() } }
    }

    override fun onDestroy() { p.unregisterOnSharedPreferenceChangeListener(ls); super.onDestroy() }

    private fun start() {
        val need = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        perm.launch(need.toTypedArray())
    }

    @SuppressLint("MissingPermission")
    private fun arm() {
        LocationServices.getFusedLocationProviderClient(this)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { l ->
                if (l == null) { Toast.makeText(this, "GPS চালু করে আবার চেষ্টা করুন", Toast.LENGTH_LONG).show(); return@addOnSuccessListener }
                p.edit().putString("lat", l.latitude.toString()).putString("lon", l.longitude.toString())
                    .putFloat("dist", 0f).putBoolean("armed", true).putBoolean("run", true).apply()
                ContextCompat.startForegroundService(this, Intent(this, GuardService::class.java))
                if (!getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName))
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun sync() = ContextCompat.startForegroundService(this, Intent(this, GuardService::class.java))

    private fun bat() {
        if (!getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName))
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
    }

    @SuppressLint("MissingPermission")
    private fun pickHome() {
        LocationServices.getFusedLocationProviderClient(this).getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { l -> if (l == null) toast("GPS চালু করে আবার চেষ্টা করুন") else homeTxt = "${l.latitude}, ${l.longitude}" }
    }

    private fun saveHome(): Boolean {
        val x = homeTxt.split(",").mapNotNull { it.trim().toDoubleOrNull() }
        if (x.size != 2 || x[0] !in -90.0..90.0 || x[1] !in -180.0..180.0) { toast("বাড়ির লোকেশন ঠিক নেই (উদাহরণ: 24.3745, 91.4158)"); return false }
        p.edit().putString("hlat", x[0].toString()).putString("hlon", x[1].toString()).apply()
        return true
    }

    private fun goHome() {
        if (!saveHome()) return
        p.edit().putBoolean("homeSched", true).putBoolean("run", true).putBoolean("armed", false).apply()
        sync(); bat()
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun UI() {
        var tok by remember { mutableStateOf(p.getString("tok", "")!!) }
        var chat by remember { mutableStateOf(p.getString("chat", "")!!) }
        var r by remember { mutableStateOf(p.getInt("r", 60)) }
        var hr by remember { mutableStateOf(p.getInt("hr", 100)) }
        val inside = dist <= (if (armed) p.getInt("r", 60) else r)
        Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("🚗 Vehicle Guard", style = MaterialTheme.typography.headlineMedium)
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(
                containerColor = if (!run) Color(0xFFEEEEEE) else if (!armed) Color(0xFFFFF3C4) else if (inside) Color(0xFFD7F5DD) else Color(0xFFFFD9D6))) {
                Column(Modifier.padding(20.dp)) {
                    Text(if (!run) "⚪ সুরক্ষা বন্ধ" else if (!armed) "🟡 বিরতিতে (বট থেকে /on দিন)" else if (inside) "🟢 নিরাপদ এলাকায়" else "🔴 গাড়ি সরে গেছে!", style = MaterialTheme.typography.titleLarge)
                    if (run && armed) Text("পার্কিং থেকে দূরত্ব: ${dist.toInt()} মিটার")
                }
            }
            Text("🏠 বাড়ি নজরদারি (পৌঁছালে ও বের হলে জানাবে)", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(homeTxt, { homeTxt = it }, Modifier.fillMaxWidth(), label = { Text("বাড়ির লোকেশন (lat, lon)") }, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ mode = 2; start() }) { Text("📌 এখানের লোকেশন") }
                OutlinedButton({ if (saveHome() && run) sync() }) { Text("💾 সেভ") }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("বাড়ির সীমা")
                listOf(40, 60, 100, 150, 200).forEach { FilterChip(hr == it, { hr = it; p.edit().putInt("hr", it).apply() }, { Text("$it মি") }) }
            }
            if (run) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("বাড়ি নজরদারি (রাত ১২টা–সকাল ৮টা অটো)")
                Switch(homeOn, { on -> if (!on || saveHome()) { p.edit().putBoolean("homeSched", on).apply(); sync() } })
            }
            if (!run) {
                Text("সীমা (Radius)")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(40, 60, 100, 250, 500).forEach { FilterChip(r == it, { r = it }, { Text("$it মি") }) }
                }
                OutlinedTextField(tok, { tok = it }, Modifier.fillMaxWidth(), label = { Text("Telegram Bot Token") }, singleLine = true)
                OutlinedTextField(chat, { chat = it }, Modifier.fillMaxWidth(), label = { Text("Telegram Chat ID") }, singleLine = true)
                Button({ p.edit().putString("tok", tok.trim()).putString("chat", chat.trim()).putInt("r", r).apply(); mode = 0; start() },
                    Modifier.fillMaxWidth().height(56.dp), enabled = tok.isNotBlank() && chat.isNotBlank()) {
                    Text("📍 এখানে পার্ক করেছি — চালু করুন")
                }
                OutlinedButton({ p.edit().putString("tok", tok.trim()).putString("chat", chat.trim()).apply(); mode = 1; start() },
                    Modifier.fillMaxWidth().height(56.dp), enabled = tok.isNotBlank() && chat.isNotBlank()) {
                    Text("🏠 শুধু বাড়ি-নজরদারি চালু")
                }
            } else {
                Text("বট থেকে: /on চালু · /off বন্ধ · /status · /where")
                Button({ startService(Intent(this@MainActivity, GuardService::class.java).setAction("STOP")) },
                    Modifier.fillMaxWidth().height(56.dp)) { Text("পুরো বন্ধ করুন") }
            }
        }
    }
}
