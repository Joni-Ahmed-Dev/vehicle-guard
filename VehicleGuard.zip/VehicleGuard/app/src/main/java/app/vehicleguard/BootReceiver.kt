package app.vehicleguard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (c.getSharedPreferences("g", 0).getBoolean("run", false))
            try { ContextCompat.startForegroundService(c, Intent(c, GuardService::class.java)) } catch (_: Exception) {}
    }
}
