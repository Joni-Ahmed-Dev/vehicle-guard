package app.vehicleguard

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import com.google.android.gms.location.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class GuardService : Service() {
    private lateinit var p: SharedPreferences
    private val client by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private val h = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var outN = 0L // সীমার বাইরে যাওয়ার সময়
    private var wl: PowerManager.WakeLock? = null
    private var alerted = false
    private var lastPin = 0L
    private var hState = 0 // 0 অজানা, 1 বাড়িতে, 2 বাইরে
    private var hPend = 0
    private var hAct = false
    private val cb = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) { r.lastLocation?.let { check(it) } }
    }

    override fun onBind(i: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        p = getSharedPreferences("g", 0)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("g", "Vehicle Guard", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP" || !p.getBoolean("run", false)) { stopAll(); return START_NOT_STICKY }
        val n = Notification.Builder(this, "g").setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Vehicle Guard চালু").setContentText("Telegram বট থেকে নিয়ন্ত্রণ করা যাবে").build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        else startForeground(1, n)
        if (!running) { running = true; poll() }
        if (wl == null) wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "vg:w").apply { acquire() }
        sync()
        hAct = homeNow(); h.removeCallbacks(tick); h.postDelayed(tick, 30000)
        if (i != null) tg("✅ সুরক্ষা চালু। সীমা: ${p.getInt("r", 60)} মিটার\nবট কমান্ড: /on /off /status /where /radius 250")
        return START_STICKY
    }

    private fun stopAll() {
        running = false; h.removeCallbacks(tick); unwatch(); wl?.release(); wl = null
        p.edit().putBoolean("run", false).putBoolean("armed", false).apply()
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    @SuppressLint("MissingPermission")
    private fun watch() {
        outN = 0; alerted = false; hState = 0; hPend = 0
        client.requestLocationUpdates(
            LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000).build(),
            cb, Looper.getMainLooper()
        )
    }

    private fun sync() { if (p.getBoolean("armed", false) || homeNow()) watch() else unwatch() }

    // বাড়ির নজরদারি: প্রতিদিন রাত ১২টা থেকে সকাল ৮টা (ফোনের স্থানীয় সময়) অটো চালু
    private fun homeNow() = p.getBoolean("homeSched", true) && p.getString("hlat", null) != null &&
        java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) < 8

    private fun tickNow(silent: Boolean) {
        val n = homeNow()
        if (n == hAct) return
        hAct = n; hState = 0; hPend = 0
        if (!p.getBoolean("armed", false)) sync()
        if (!silent) tg(if (n) "🌙 বাড়ি নজরদারি চালু হলো (সকাল ৮টা পর্যন্ত)" else "☀️ বাড়ি নজরদারি বন্ধ হলো (আবার রাত ১২টায় চালু হবে)")
    }

    private val tick = object : Runnable { override fun run() { tickNow(false); h.postDelayed(this, 30000) } }

    private fun unwatch() { client.removeLocationUpdates(cb) }

    private fun poll() = Thread {
        var off = 0L
        while (running) {
            try {
                val c = URL("https://api.telegram.org/bot${p.getString("tok", "")}/getUpdates?timeout=30&offset=${off + 1}")
                    .openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 40000
                val arr = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("result")
                for (k in 0 until arr.length()) {
                    val u = arr.getJSONObject(k); off = u.getLong("update_id")
                    val m = u.optJSONObject("message") ?: continue
                    if (m.getJSONObject("chat").getLong("id").toString() != p.getString("chat", "")) continue
                    if (m.getLong("date") < System.currentTimeMillis() / 1000 - 90) continue // পুরোনো কমান্ড বাদ
                    val t = m.optString("text", "").trim().lowercase()
                    h.post { cmd(t) }
                }
            } catch (_: Exception) { Thread.sleep(5000) }
        }
    }.start()

    @SuppressLint("MissingPermission")
    private fun here(then: (Location) -> Unit) {
        client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).addOnSuccessListener { l ->
            if (l == null) tg("⚠️ গাড়ির ফোনে GPS পাওয়া যাচ্ছে না") else then(l)
        }
    }

    private fun cmd(t: String) {
        when (t.split(" ", "@")[0]) {
            "/on", "/set" -> here { l ->
                p.edit().putString("lat", l.latitude.toString()).putString("lon", l.longitude.toString())
                    .putFloat("dist", 0f).putBoolean("armed", true).apply()
                watch()
                tg("✅ গাড়ির বর্তমান জায়গা পার্কিং ধরা হয়েছে। সুরক্ষা চালু, সীমা ${p.getInt("r", 60)} মিটার")
                pin(l)
            }
            "/off" -> {
                p.edit().putBoolean("armed", false).apply(); sync()
                tg("⏸ সুরক্ষা বন্ধ। আবার চালু করতে /on দিন")
            }
            "/status" -> tg(
                (if (!p.getBoolean("armed", false)) "⏸ পার্কিং-পাহারা বন্ধ"
                else "🛡 পার্কিং-পাহারা চালু। দূরত্ব ${p.getFloat("dist", 0f).toInt()} মিটার, সীমা ${p.getInt("r", 60)} মিটার") +
                "\n🏠 বাড়ি: " + (if (!homeNow()) "বন্ধ (রাত ১২টা–সকাল ৮টায় অটো চালু)" else when (hState) { 1 -> "গাড়ি বাড়িতে"; 2 -> "গাড়ি বাইরে"; else -> "অবস্থা জানা হচ্ছে" })
            )
            "/homeon" -> if (p.getString("hlat", null) == null) tg("⚠️ আগে বাড়ির লোকেশন দিন: অ্যাপে সেভ করুন, বা গাড়ি বাড়িতে থাকলে /sethome দিন")
            else { p.edit().putBoolean("homeSched", true).apply(); tickNow(true); tg("🏠 অটো বাড়ি নজরদারি চালু: প্রতিদিন রাত ১২টা–সকাল ৮টা। সীমা ${p.getInt("hr", 100)} মিটার") }
            "/homeoff" -> { p.edit().putBoolean("homeSched", false).apply(); tickNow(true); tg("🏠 অটো বাড়ি নজরদারি বন্ধ। আবার চালু করতে /homeon") }
            "/sethome" -> here { l ->
                p.edit().putString("hlat", l.latitude.toString()).putString("hlon", l.longitude.toString()).apply()
                tickNow(true); tg("📌 গাড়ির এখনকার জায়গা বাড়ি হিসেবে সেভ হয়েছে"); pin(l)
            }
            "/homeradius" -> { val v = t.split(" ").getOrNull(1)?.toIntOrNull()
                if (v == null) tgk("🏠 বাড়ির সীমা বেছে নিন (এখন ${p.getInt("hr", 100)} মি)", """{"keyboard":[["/homeradius 40","/homeradius 60","/homeradius 100"],["/homeradius 150","/homeradius 200","/status"]],"resize_keyboard":true}""")
                else if (v in 20..5000) { p.edit().putInt("hr", v).apply(); tg("বাড়ির সীমা এখন $v মিটার") } }
            "/where" -> here { pin(it) }
            "/radius" -> { val v = t.split(" ").getOrNull(1)?.toIntOrNull()
                if (v == null) tgk("🛡 পার্কিং সীমা বেছে নিন (এখন ${p.getInt("r", 60)} মি)", """{"keyboard":[["/radius 40","/radius 60","/radius 100"],["/radius 250","/radius 500","/status"]],"resize_keyboard":true}""")
                else if (v in 20..5000) { p.edit().putInt("r", v).apply(); tg("সীমা এখন $v মিটার") } }
            else -> tg("কমান্ড:\n/on — গাড়ির এখনকার জায়গা পার্কিং ধরে চালু\n/off — সুরক্ষা বন্ধ\n/status — অবস্থা\n/where — গাড়ির অবস্থান\n/radius — পার্কিং সীমা বাছুন (বা /radius 80)\n/homeon /homeoff — রাত ১২টা–সকাল ৮টার অটো বাড়ি নজরদারি চালু/বন্ধ\n/sethome — গাড়ির জায়গা বাড়ি ধরুন\n/homeradius — বাড়ির সীমা বাছুন")
        }
    }

    private fun check(l: Location) {
        if (l.accuracy > 100f) return // খারাপ GPS রিডিং বাদ
        if (homeNow()) home(l)
        if (p.getBoolean("armed", false)) guard(l)
    }

    private fun home(l: Location) {
        val d = FloatArray(1)
        Location.distanceBetween(p.getString("hlat", "0")!!.toDouble(), p.getString("hlon", "0")!!.toDouble(), l.latitude, l.longitude, d)
        val r = p.getInt("hr", 100)
        val want = if (d[0] <= r) 1 else if (d[0] > r + 30) 2 else hState // মাঝের ৩০ মি = নিরপেক্ষ এলাকা
        if (want == hState) { hPend = 0; return }
        if (hState == 0) { hState = want; return } // প্রথম রিডিংয়ে চুপচাপ অবস্থা ধরা হয়
        if (r < 100 && hPend != want) { hPend = want; return } // ছোট সীমায় টানা ২টা রিডিং লাগবে
        hState = want; hPend = 0
        tg(if (want == 1) "🏠 গাড়ি বাড়িতে পৌঁছেছে" else "🚗 গাড়ি বাড়ি থেকে বেরিয়েছে")
        pin(l)
    }

    private fun guard(l: Location) {
        val d = FloatArray(1)
        Location.distanceBetween(p.getString("lat", "0")!!.toDouble(), p.getString("lon", "0")!!.toDouble(), l.latitude, l.longitude, d)
        p.edit().putFloat("dist", d[0]).apply()
        val now = System.currentTimeMillis()
        if (d[0] <= p.getInt("r", 60)) {
            if (alerted) tg("✅ গাড়ি আবার নিরাপদ এলাকায় ফিরেছে")
            outN = 0; alerted = false
            return
        }
        if (outN == 0L) outN = now
        if (now - outN < 15000) return // টানা ১৫ সেকেন্ড বাইরে থাকলে অ্যালার্ট (মোট প্রায় ২০ সেকেন্ড)
        if (!alerted) {
            alerted = true; lastPin = now
            tg("🚨 গাড়ি নিরাপদ এলাকা ছেড়েছে!\nদূরত্ব: ${d[0].toInt()} মিটার")
            pin(l)
        } else if (now - lastPin > 60000) {
            lastPin = now; pin(l)
        }
    }

    private val kb = """{"keyboard":[["/on","/off"],["/homeon","/homeoff"],["/radius","/homeradius"],["/status","/where","/sethome"]],"resize_keyboard":true}"""
    private fun tg(t: String) = tgk(t, kb)
    private fun tgk(t: String, k: String) = call("sendMessage", "text=" + URLEncoder.encode(t, "UTF-8") + "&reply_markup=" + URLEncoder.encode(k, "UTF-8"))
    private fun pin(l: Location) = call("sendLocation", "latitude=${l.latitude}&longitude=${l.longitude}")

    private fun call(m: String, q: String) = Thread {
        val u = "https://api.telegram.org/bot${p.getString("tok", "")}/$m?chat_id=${p.getString("chat", "")}&$q"
        repeat(6) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 10000
                if (c.responseCode == 200) return@Thread
            } catch (_: Exception) {}
            Thread.sleep(10000)
        }
    }.start()

    override fun onDestroy() { running = false; h.removeCallbacks(tick); unwatch(); wl?.release(); wl = null; super.onDestroy() }
}
