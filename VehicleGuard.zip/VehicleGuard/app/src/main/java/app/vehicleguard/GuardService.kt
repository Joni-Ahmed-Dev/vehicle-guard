package app.vehicleguard

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.Looper
import com.google.android.gms.location.*
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class GuardService : Service() {
    private lateinit var p: SharedPreferences
    private val client by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private var outsideSince = 0L
    private var alerted = false
    private var lastPin = 0L
    private val cb = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) { r.lastLocation?.let { check(it) } }
    }

    override fun onBind(i: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        p = getSharedPreferences("g", 0)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("g", "Vehicle Guard", NotificationManager.IMPORTANCE_LOW))
    }

    @SuppressLint("MissingPermission")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP" || !p.getBoolean("armed", false)) {
            p.edit().putBoolean("armed", false).apply()
            client.removeLocationUpdates(cb)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val n = Notification.Builder(this, "g").setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Vehicle Guard চালু").setContentText("গাড়ি পাহারা দেওয়া হচ্ছে").build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        else startForeground(1, n)
        client.requestLocationUpdates(
            LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 20000).setMinUpdateDistanceMeters(5f).build(),
            cb, Looper.getMainLooper()
        )
        if (i != null) tg("✅ সুরক্ষা চালু। সীমা: ${p.getInt("r", 250)} মিটার")
        return START_STICKY
    }

    private fun check(l: Location) {
        val d = FloatArray(1)
        Location.distanceBetween(p.getString("lat", "0")!!.toDouble(), p.getString("lon", "0")!!.toDouble(), l.latitude, l.longitude, d)
        p.edit().putFloat("dist", d[0]).apply()
        val now = System.currentTimeMillis()
        if (d[0] <= p.getInt("r", 250)) {
            if (alerted) tg("✅ গাড়ি আবার নিরাপদ এলাকায় ফিরেছে")
            outsideSince = 0; alerted = false
            return
        }
        if (outsideSince == 0L) outsideSince = now
        if (now - outsideSince < 30000) return // GPS ঝামেলায় ভুল alert ঠেকাতে ৩০ সেকেন্ড অপেক্ষা
        if (!alerted) {
            alerted = true; lastPin = now
            tg("🚨 গাড়ি নিরাপদ এলাকা ছেড়েছে!\nদূরত্ব: ${d[0].toInt()} মিটার")
            pin(l)
        } else if (now - lastPin > 60000) {
            lastPin = now; pin(l)
        }
    }

    private fun tg(t: String) = call("sendMessage", "text=" + URLEncoder.encode(t, "UTF-8"))
    private fun pin(l: Location) = call("sendLocation", "latitude=${l.latitude}&longitude=${l.longitude}")

    private fun call(m: String, q: String) = Thread {
        val u = "https://api.telegram.org/bot${p.getString("tok", "")}/$m?chat_id=${p.getString("chat", "")}&$q"
        repeat(6) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 10000
                if (c.responseCode == 200) return@Thread
            } catch (_: Exception) {}
            Thread.sleep(10000)
        }
    }.start()

    override fun onDestroy() { client.removeLocationUpdates(cb); super.onDestroy() }
}
