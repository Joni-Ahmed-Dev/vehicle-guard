package app.vehicleguard

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.google.android.gms.location.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class GuardService : Service() {
    private lateinit var p: SharedPreferences
    private val client by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private val h = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var outsideSince = 0L
    private var alerted = false
    private var lastPin = 0L
    private val cb = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) { r.lastLocation?.let { check(it) } }
    }

    override fun onBind(i: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        p = getSharedPreferences("g", 0)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("g", "Vehicle Guard", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP" || !p.getBoolean("run", false)) { stopAll(); return START_NOT_STICKY }
        val n = Notification.Builder(this, "g").setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Vehicle Guard চালু").setContentText("Telegram বট থেকে নিয়ন্ত্রণ করা যাবে").build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        else startForeground(1, n)
        if (!running) { running = true; poll() }
        if (p.getBoolean("armed", false)) watch()
        if (i != null) tg("✅ সুরক্ষা চালু। সীমা: ${p.getInt("r", 250)} মিটার\nবট কমান্ড: /on /off /status /where /radius 250")
        return START_STICKY
    }

    private fun stopAll() {
        running = false; unwatch()
        p.edit().putBoolean("run", false).putBoolean("armed", false).apply()
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    @SuppressLint("MissingPermission")
    private fun watch() {
        outsideSince = 0; alerted = false
        client.requestLocationUpdates(
            LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 20000).setMinUpdateDistanceMeters(5f).build(),
            cb, Looper.getMainLooper()
        )
    }

    private fun unwatch() { client.removeLocationUpdates(cb) }

    private fun poll() = Thread {
        var off = 0L
        while (running) {
            try {
                val c = URL("https://api.telegram.org/bot${p.getString("tok", "")}/getUpdates?timeout=30&offset=${off + 1}")
                    .openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 40000
                val arr = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("result")
                for (k in 0 until arr.length()) {
                    val u = arr.getJSONObject(k); off = u.getLong("update_id")
                    val m = u.optJSONObject("message") ?: continue
                    if (m.getJSONObject("chat").getLong("id").toString() != p.getString("chat", "")) continue
                    if (m.getLong("date") < System.currentTimeMillis() / 1000 - 90) continue // পুরোনো কমান্ড বাদ
                    val t = m.optString("text", "").trim().lowercase()
                    h.post { cmd(t) }
                }
            } catch (_: Exception) { Thread.sleep(5000) }
        }
    }.start()

    @SuppressLint("MissingPermission")
    private fun here(then: (Location) -> Unit) {
        client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).addOnSuccessListener { l ->
            if (l == null) tg("⚠️ গাড়ির ফোনে GPS পাওয়া যাচ্ছে না") else then(l)
        }
    }

    private fun cmd(t: String) {
        when (t.split(" ", "@")[0]) {
            "/on", "/set" -> here { l ->
                p.edit().putString("lat", l.latitude.toString()).putString("lon", l.longitude.toString())
                    .putFloat("dist", 0f).putBoolean("armed", true).apply()
                watch()
                tg("✅ গাড়ির বর্তমান জায়গা পার্কিং ধরা হয়েছে। সুরক্ষা চালু, সীমা ${p.getInt("r", 250)} মিটার")
                pin(l)
            }
            "/off" -> {
                p.edit().putBoolean("armed", false).apply(); unwatch()
                tg("⏸ সুরক্ষা বন্ধ। আবার চালু করতে /on দিন")
            }
            "/status" -> tg(
                if (!p.getBoolean("armed", false)) "⏸ সুরক্ষা বন্ধ আছে"
                else "🛡 চালু আছে। পার্কিং থেকে দূরত্ব ${p.getFloat("dist", 0f).toInt()} মিটার, সীমা ${p.getInt("r", 250)} মিটার"
            )
            "/where" -> here { pin(it) }
            "/radius" -> t.split(" ").getOrNull(1)?.toIntOrNull()?.let {
                if (it in 20..5000) { p.edit().putInt("r", it).apply(); tg("সীমা এখন $it মিটার") }
            }
            else -> tg("কমান্ড:\n/on — গাড়ির এখনকার জায়গা পার্কিং ধরে চালু\n/off — সুরক্ষা বন্ধ\n/status — অবস্থা\n/where — গাড়ির অবস্থান\n/radius 250 — সীমা বদলান")
        }
    }

    private fun check(l: Location) {
        val d = FloatArray(1)
        Location.distanceBetween(p.getString("lat", "0")!!.toDouble(), p.getString("lon", "0")!!.toDouble(), l.latitude, l.longitude, d)
        p.edit().putFloat("dist", d[0]).apply()
        val now = System.currentTimeMillis()
        if (d[0] <= p.getInt("r", 250)) {
            if (alerted) tg("✅ গাড়ি আবার নিরাপদ এলাকায় ফিরেছে")
            outsideSince = 0; alerted = false
            return
        }
        if (outsideSince == 0L) outsideSince = now
        if (now - outsideSince < 30000) return
        if (!alerted) {
            alerted = true; lastPin = now
            tg("🚨 গাড়ি নিরাপদ এলাকা ছেড়েছে!\nদূরত্ব: ${d[0].toInt()} মিটার")
            pin(l)
        } else if (now - lastPin > 60000) {
            lastPin = now; pin(l)
        }
    }

    private fun tg(t: String) = call("sendMessage", "text=" + URLEncoder.encode(t, "UTF-8"))
    private fun pin(l: Location) = call("sendLocation", "latitude=${l.latitude}&longitude=${l.longitude}")

    private fun call(m: String, q: String) = Thread {
        val u = "https://api.telegram.org/bot${p.getString("tok", "")}/$m?chat_id=${p.getString("chat", "")}&$q"
        repeat(6) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 10000
                if (c.responseCode == 200) return@Thread
            } catch (_: Exception) {}
            Thread.sleep(10000)
        }
    }.start()

    override fun onDestroy() { running = false; unwatch(); super.onDestroy() }
}
